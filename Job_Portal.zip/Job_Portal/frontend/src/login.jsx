import React, { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";

function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({
    email: "",
    password: "",
    role: "student",
  });
  const [errorMessage, setErrorMessage] = useState("");

  // Validation regex patterns
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;
  const [errors, setErrors] = useState({});

  // Clear form on mount to avoid browser autofill; prefill email if passed via navigation state
  useEffect(() => {
    if (location.state?.prefilledEmail) {
      setForm(prev => ({ ...prev, email: location.state.prefilledEmail, password: "" }));
    } else {
      // Immediate clear (best-effort)
      setForm({ email: "", password: "", role: "student" });
      setErrors({});
      setErrorMessage("");

      // Timed clear to override browsers that autofill after render
      const t = setTimeout(() => {
        setForm({ email: "", password: "", role: "student" });
      }, 150);

      return () => clearTimeout(t);
    }
  }, [location.state]);

  // Hardcoded existing users (database simulation)
  const existingUsers = [
    { fullname: "Demo Student", email: "student@example.com", password: "password123", role: "student" },
    { fullname: "Demo Recruiter", email: "recruiter@example.com", password: "password123", role: "recruiter" },
    { fullname: "John Doe", email: "john@gmail.com", password: "john123", role: "student" },
    { fullname: "Admin Recruiter", email: "admin@company.com", password: "admin123", role: "recruiter" },
  ];

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Basic client-side validation
    if (!emailRegex.test(form.email) || !passwordRegex.test(form.password)) {
      const newErrors = {};
      if (!emailRegex.test(form.email)) newErrors.email = "Enter a valid email address.";
      if (!passwordRegex.test(form.password)) newErrors.password = "Password must be at least 8 characters and include letters and numbers.";
      setErrors(newErrors);
      return;
    } else {
      setErrors({});
    }


    let allUsers = [
      { fullname: "Demo Student", email: "student@example.com", password: "password123", role: "student" },
      { fullname: "Demo Recruiter", email: "recruiter@example.com", password: "password123", role: "recruiter" },
      { fullname: "John Doe", email: "john@gmail.com", password: "john123", role: "student" },
      { fullname: "Admin Recruiter", email: "admin@company.com", password: "admin123", role: "recruiter" },
    ];

    const registeredUsers = JSON.parse(localStorage.getItem("registeredUsers")) || [];
    
    allUsers = [...allUsers, ...registeredUsers];

    // Verify if user exists with correct password
    const userExists = allUsers.find(
      (user) => user.email === form.email && user.password === form.password
    );

    if (userExists) {
      console.log("Login successful:", form);
      setErrorMessage("");
      navigate("/dashboard", {
        state: {
          userName: userExists.fullname || form.email.split('@')[0],
          userEmail: form.email,
          userRole: userExists.role,
        }
      });
    } else {
      console.log("User not found. Redirecting to register...");
      setErrorMessage("You don't have account because you have not registered");
      setTimeout(() => {
        navigate("/register", {
          state: {
            prefilledEmail: form.email,
            message: "User not found. Please register first.",
          }
        });
      }, 2000);
    }
  };

  const fillDemoStudent = () => {
    setForm({
      email: "student@example.com",
      password: "password123",
      role: "student",
    });
  };

  const fillDemoRecruiter = () => {
    setForm({
      email: "recruiter@example.com",
      password: "password123",
      role: "recruiter",
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="w-full max-w-md bg-white p-8 rounded-xl shadow">

        <h2 className="text-2xl font-bold text-center mb-6">
          Login
        </h2>

        {errorMessage && (
          <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} autoComplete="off" className="space-y-4">
          <input type="text" name="prevent_autofill" autoComplete="off" style={{ display: 'none' }} />
          

          <input
            type="email"
            name="email"
            placeholder="Email address"
            value={form.email}
            onChange={handleChange}
            required
            autoComplete="email"
            className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {errors.email && <p className="text-red-600 text-sm mt-1">{errors.email}</p>} 

          <input
            type="password"
            name="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
            required
            autoComplete="new-password"
            className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {errors.password && <p className="text-red-600 text-sm mt-1">{errors.password}</p>} 

          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="role"
                value="student"
                checked={form.role === "student"}
                onChange={handleChange}
                className="w-4 h-4 text-blue-600"
              />
              <span>Student</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="role"
                value="recruiter"
                checked={form.role === "recruiter"}
                onChange={handleChange}
                className="w-4 h-4 text-blue-600"
              />
              <span>Recruiter</span>
            </label>
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
          >
            Login
          </button>
        </form>

        <div className="mt-4 flex gap-2">
          <button onClick={fillDemoStudent} className="flex-1 text-xs bg-gray-200 hover:bg-gray-300 py-2 rounded">Demo Student</button>
          <button onClick={fillDemoRecruiter} className="flex-1 text-xs bg-gray-200 hover:bg-gray-300 py-2 rounded">Demo Recruiter</button>
        </div>

        {/* 🔗 Back to Home (since no login page yet) */}
        <p className="text-center text-sm text-gray-600 mt-6">
          Not have any account?{" "}
          <Link
            to="/register"
            className="text-blue-600 font-medium hover:underline"
          >
            Register
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Login;