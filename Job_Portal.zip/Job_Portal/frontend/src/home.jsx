import React, { useState } from "react";
import { Link } from "react-router-dom";

function Home() {
  const [keyword, setKeyword] = useState("");
  const [location, setLocation] = useState("");

  const handleSearch = () => {
    console.log("Search:", { keyword, location });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">



      <section
        className="relative flex flex-col items-center justify-center px-6 py-28 text-center text-white"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,0,0,.65),rgba(0,0,0,.65)),url('https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?q=80&w=2072')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
          Find Jobs That Match <span className="text-green-400">Your Skills</span>
        </h1>

        <p className="text-slate-200 max-w-xl">
          Apply to verified jobs from startups to top companies — faster & smarter.
        </p>

        <div className="mt-8 flex flex-col sm:flex-row gap-3 bg-white/10 backdrop-blur p-4 rounded-xl">
          <input
            className="px-4 py-3 rounded-lg text-slate-900 outline-none w-64 placeholder-white"
            placeholder="Job title or keyword"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
          />
          <input
            className="px-4 py-3 rounded-lg text-slate-900 outline-none w-48 placeholder-white"
            placeholder="Location or Remote"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
          <button
            className="px-6 py-3 bg-blue-600 rounded-lg hover:bg-blue-700 transition"
            onClick={handleSearch}
          >
            Search Jobs
          </button>
        </div>
      </section>

      <section className="relative -mt-16 z-10">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 text-white shadow-xl">

            <div className="text-center">
              <h3 className="text-3xl font-bold">10k+</h3>
              <p className="text-blue-100">Active Job Seekers</p>
            </div>

            <div className="text-center">
              <h3 className="text-3xl font-bold">500+</h3>
              <p className="text-blue-100">Hiring Companies</p>
            </div>

            <div className="text-center">
              <h3 className="text-3xl font-bold">Fast</h3>
              <p className="text-blue-100">Hiring Process</p>
            </div>

          </div>
        </div>
      </section>

      <section className="py-20 px-6 text-center">
        <h2 className="text-3xl font-bold mb-10">How It Works</h2>

        <div className="grid gap-6 sm:grid-cols-3 max-w-5xl mx-auto">
          {["Create Profile", "Search Jobs", "Apply Instantly"].map((item) => (
            <div
              key={item}
              className="bg-white p-6 rounded-xl shadow hover:shadow-lg transition"
            >
              <h3 className="font-semibold text-lg">{item}</h3>
            </div>
          ))}
        </div>
      </section>

      <section className="py-12 bg-white text-center">
        <p className="text-slate-500 mb-6">Trusted by top companies</p>

        <div className="flex flex-wrap justify-center gap-8 opacity-80">
          {[
            "google.com",
            "amazon.com",
            "microsoft.com",
            "meta.com",
            "netflix.com",
            "apple.com",
            "adobe.com",
            "spotify.com",
            "uber.com",
          ].map((d) => (
            <img
              key={d}
              src={`https://icons.duckduckgo.com/ip3/${d}`}
              alt={d}

              className="h-8 grayscale hover:grayscale-0 transition"
            />
          ))}
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
          {[
            ["Easy Apply", "Apply with one click"],
            ["Best Salary", "Get paid what you deserve"],
            ["Verified Jobs", "No fake listings"],
            ["Fast Hiring", "Quick recruiter response"],
            ["Remote Jobs", "Work from anywhere"],
            ["Career Growth", "Level up your career"],
          ].map(([title, text]) => (
            <div
              key={title}
              className="bg-white p-6 rounded-xl shadow hover:-translate-y-1 transition"
            >
              <h3 className="font-semibold text-lg mb-2">{title}</h3>
              <p className="text-slate-600 text-sm">{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-20 bg-slate-100 text-center">
        <h2 className="text-3xl font-bold mb-8">What users say</h2>

        <div className="flex flex-wrap justify-center gap-6">
          {[
            "Got my first dev job in 3 weeks. – Aman",
            "Clean UI and real jobs. – Neha",
          ].map((t) => (
            <div
              key={t}
              className="bg-white p-6 rounded-xl shadow max-w-xs italic"
            >
              {t}
            </div>
          ))}
        </div>
      </section>

      <section className="py-20 text-center bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <h2 className="text-3xl font-bold mb-4">Ready to get hired?</h2>
        <Link to="/register">
          <button className="px-8 py-3 bg-green-500 rounded-lg hover:bg-green-600 transition">
            Create Your Profile
          </button>
        </Link>
      </section>

      <section className="grid grid-cols-3 text-center py-10 bg-blue-600 text-white">
        {[
          ["10k+", "Users"],
          ["500+", "Companies"],
          ["100+", "Cities"],
        ].map(([num, label]) => (
          <div key={label}>
            <h3 className="text-2xl font-bold">{num}</h3>
            <p className="text-blue-100">{label}</p>
          </div>
        ))}
      </section>

      <footer className="text-center py-4 text-slate-500 text-sm">
        © 2026 JobPortal · Built for growth
      </footer>

    </div>
  );
}

export default Home;
