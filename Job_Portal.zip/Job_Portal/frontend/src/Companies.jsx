import React from "react";
import { Link } from "react-router-dom";

function Companies() {
  const companies = [
    { id: 1, name: "Google", size: "Large", location: "Mountain View" },
    { id: 2, name: "StartupX", size: "Small", location: "Remote" },
    { id: 3, name: "Acme Corp", size: "Medium", location: "New York" },
  ];

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Companies</h1>
        <div className="grid gap-4 sm:grid-cols-2">
          {companies.map((c) => (
            <div key={c.id} className="bg-white p-4 rounded-xl shadow">
              <h3 className="font-semibold">{c.name}</h3>
              <p className="text-sm text-slate-600">{c.size} • {c.location}</p>
              <div className="mt-4">
                <Link to="/" className="text-blue-600 hover:underline">View jobs</Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Companies;
