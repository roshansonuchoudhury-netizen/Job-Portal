import React from "react";
import { Outlet, Link } from "react-router-dom";

function Resources() {
  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Resources</h1>

        <div className="mb-4 flex gap-3">
          <Link to="/resources" className="px-3 py-1 rounded bg-white shadow-sm text-sm">Overview</Link>
          <Link to="articles" className="px-3 py-1 rounded bg-white shadow-sm text-sm">Articles</Link>
          <Link to="videos" className="px-3 py-1 rounded bg-white shadow-sm text-sm">Videos</Link>
        </div>

        <Outlet />
      </div>
    </div>
  );
}

export default Resources;
