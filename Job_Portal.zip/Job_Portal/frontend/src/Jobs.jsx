import React from "react";
import { Link } from "react-router-dom";

function Jobs() {
  const jobs = [
    { id: 1, title: "Senior React Developer", company: "Google", location: "Mountain View, CA", remote: false },
    { id: 2, title: "Frontend Engineer", company: "StartupX", location: "Remote", remote: true },
    { id: 3, title: "Full Stack Developer", company: "Acme Corp", location: "New York, NY", remote: false },
  ];

  const handleApply = (job) => {
    const appliedJobs = JSON.parse(localStorage.getItem("appliedJobs")) || [];
    const isApplied = appliedJobs.some(appliedJob => appliedJob.id === job.id);

    if (isApplied) {
      alert(`You have already applied for "${job.title}".`);
    } else {
      appliedJobs.push(job);
      localStorage.setItem("appliedJobs", JSON.stringify(appliedJobs));
      alert(`Application for "${job.title}" was successful!`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Jobs</h1>

        <div className="grid gap-4">
          {jobs.map((job) => (
            <div key={job.id} className="bg-white p-4 rounded-xl shadow flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-lg">{job.title}</h3>
                <p className="text-sm text-slate-600">{job.company} • {job.location}</p>
              </div>
              <div className="flex items-center gap-3">
                {job.remote && <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Remote</span>}
                <button onClick={() => handleApply(job)} className="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">Apply</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Jobs;
